package net.rasanovum.runeweaver.rosetta;

import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.rasanovum.rosetta.network.RosettaPacket;

import java.util.ArrayList;
import java.util.List;

/** One complete server-owned snapshot for one registered asset channel. */
public record AssetSnapshotS2C(class_2960 channel, List<Asset> assets) implements RosettaPacket {
    static final int MAX_WIRE_ASSET_BYTES = 16 * 1024 * 1024;
    static final int MAX_WIRE_ASSETS = 4096;
    static final long MAX_WIRE_TOTAL_BYTES = 32L * 1024 * 1024;

    public AssetSnapshotS2C {
        assets = assets == null ? List.of() : List.copyOf(assets);
        if (assets.size() > MAX_WIRE_ASSETS) throw new IllegalArgumentException("Too many assets: " + assets.size());
        long totalBytes = 0;
        for (Asset asset : assets) {
            if (asset.bytes.length > MAX_WIRE_ASSET_BYTES) throw new IllegalArgumentException("Asset is too large: " + asset.id());
            totalBytes += asset.bytes.length;
            if (totalBytes > MAX_WIRE_TOTAL_BYTES) throw new IllegalArgumentException("Asset snapshot is too large");
        }
    }

    public AssetSnapshotS2C(class_2540 buf) {
        this(buf.method_10810(), readAssets(buf));
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10812(channel);
        buf.method_10804(assets.size());
        for (Asset asset : assets) {
            buf.method_10812(asset.id());
            buf.method_10813(asset.bytes());
        }
    }

    public static void handle(AssetSnapshotS2C packet, class_1657 player) {
        AssetChannels.handleClientSnapshot(packet);
    }

    private static List<Asset> readAssets(class_2540 buf) {
        int count = buf.method_10816();
        if (count < 0 || count > MAX_WIRE_ASSETS) throw new IllegalArgumentException("Invalid asset count: " + count);
        List<Asset> assets = new ArrayList<>(count);
        long totalBytes = 0;
        for (int i = 0; i < count; i++) {
            class_2960 id = buf.method_10810();
            byte[] bytes = buf.method_10803(MAX_WIRE_ASSET_BYTES);
            totalBytes += bytes.length;
            if (totalBytes > MAX_WIRE_TOTAL_BYTES) throw new IllegalArgumentException("Asset snapshot is too large");
            assets.add(new Asset(id, bytes));
        }
        return assets;
    }

    public record Asset(class_2960 id, byte[] bytes) {
        public Asset {
            bytes = bytes.clone();
        }

        @Override public byte[] bytes() { return bytes.clone(); }
    }
}
