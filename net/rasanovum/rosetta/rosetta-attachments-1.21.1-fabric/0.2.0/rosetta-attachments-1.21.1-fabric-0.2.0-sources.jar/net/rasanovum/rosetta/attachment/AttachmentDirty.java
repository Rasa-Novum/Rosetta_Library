package net.rasanovum.rosetta.attachment;

import net.minecraft.class_2586;
import net.minecraft.class_2791;

final class AttachmentDirty {
    private AttachmentDirty() {}

    static void mark(Object owner) {
        if (owner instanceof class_2791 chunk) {
            //? if >=26.1 {
            /*chunk.markUnsaved();
            *///?} else {
            chunk.method_12008(true);
            //?}
        } else if (owner instanceof class_2586 blockEntity) {
            blockEntity.method_5431();
        }
    }
}
