package net.rasanovum.rosetta.client.gui;

//?}
import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;

/** Opt-in vanilla adapter with stable subclass hooks. */
public abstract class CompatWidget extends class_339 {
    protected CompatWidget(int x, int y, int width, int height, class_2561 text) { super(x, y, width, height, text); }

    //? if >=26.1 {
    /*@Override
    public void extractWidgetRenderState(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    *///?} else {
    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    //?}

    protected abstract void drawWidget(class_332 graphics, int mouseX, int mouseY, float partialTick);

    //? if >=26.1 {
    /*@Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
        return onMouseClick(new MouseInput(event, doubled), () -> super.mouseClicked(event, doubled));
    }
    *///?} else {
    @Override
    public boolean method_25402(double x, double y, int button) {
        return onMouseClick(new MouseInput(x, y, button), () -> super.method_25402(x, y, button));
    }
    //?}

    protected boolean onMouseClick(MouseInput input, BooleanSupplier next) {
        return next.getAsBoolean();
    }

    //? if <1.20.2 {
    /*@Override
    public boolean mouseScrolled(double x, double y, double scrollY) {
        return onMouseScroll(x, y, 0, scrollY, () -> super.mouseScrolled(x, y, scrollY));
    }
    *///?} else {
    @Override
    public boolean method_25401(double x, double y, double scrollX, double scrollY) {
        return onMouseScroll(x, y, scrollX, scrollY, () -> super.method_25401(x, y, scrollX, scrollY));
    }
    //?}

    protected boolean onMouseScroll(double x, double y, double scrollX, double scrollY, BooleanSupplier next) {
        return next.getAsBoolean();
    }
}
