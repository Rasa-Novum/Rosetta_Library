package net.rasanovum.rosetta.util;

import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

/** Client-side helpers. */
public final class ClientCompat {
    private ClientCompat() {}

    public static boolean autoJump(class_315 options) {
        //? if <1.19 {
        /*return options.autoJump;
        *///?} else {
        return options.method_42423().method_41753();
        //?}
    }

    public static void setAutoJump(class_315 options, boolean enabled) {
        //? if <1.19 {
        /*options.autoJump = enabled;
        *///?} else {
        options.method_42423().method_41748(enabled);
        //?}
    }

    public static float fovEffectScale(class_315 options) {
        //? if <1.19 {
        /*return (float) options.fovEffectScale;
        *///?} else {
        return options.method_42454().method_41753().floatValue();
        //?}
    }

    public static class_437 screen(class_310 minecraft) {
        //? if >=26.2 {
        /*return minecraft.gui.screen();
        *///?} else {
        return minecraft.field_1755;
        //?}
    }

    public static void setScreen(class_310 minecraft, class_437 screen) {
        //? if >=26.2 {
        /*minecraft.gui.setScreen(screen);
        *///?} else {
        minecraft.method_1507(screen);
        //?}
    }

    public static class_4184 mainCamera(class_310 minecraft) {
        //? if >=26.2 {
        /*return minecraft.gameRenderer.mainCamera();
        *///?} else {
        return minecraft.field_1773.method_19418();
        //?}
    }

    public static boolean isHudHidden(class_310 minecraft) {
        //? if >=26.2 {
        /*return minecraft.gameRenderer.gameRenderState().guiRenderState.isHudHidden;
        *///?} else {
        return minecraft.field_1690.field_1842;
        //?}
    }

    public static class_2960 getPlayerSkin(class_310 minecraft, class_1657 player) {
        //? if <1.19 {
        /*return player instanceof AbstractClientPlayer clientPlayer
                ? clientPlayer.getSkinTextureLocation()
                : net.minecraft.client.resources.DefaultPlayerSkin.getDefaultSkin(player.getUUID());
        *///?} else if <1.21 {
        /*return minecraft.getSkinManager().getInsecureSkinLocation(player.getGameProfile());
        *///?} else {
        //? if >=26.1 {
        /*return ((AbstractClientPlayer) player).getSkin().body().texturePath();
        *///?} else {
        return minecraft.method_1582().method_52862(player.method_7334()).comp_1626();
        //?}
        //?}
    }

    public static class_1043 dynamicTexture(String label, net.minecraft.class_1011 image) {
        //? if >=26.1 {
        /*return new DynamicTexture(() -> label, image);
        *///?} else {
        return new class_1043(image);
        //?}
    }

    public static class_2960 registerTexture(class_1060 textureManager, String namespace, String label, class_1043 texture) {
        //? if >=26.1 {
        /*ResourceLocation id = RegistryCompat.getLocation(namespace, label);
        textureManager.register(id, texture);
        return id;
        *///?} else {
        return textureManager.method_4617(label, texture);
        //?}
    }

    public static int nativeImageGetPixel(net.minecraft.class_1011 image, int x, int y) {
        //? if >=26.1 {
        /*return image.getPixel(x, y);
        *///?} else {
        return image.method_4315(x, y);
        //?}
    }

    public static void nativeImageSetPixel(net.minecraft.class_1011 image, int x, int y, int color) {
        //? if >=26.1 {
        /*image.setPixel(x, y, color);
        *///?} else {
        image.method_4305(x, y, color);
        //?}
    }

    /** Stable mouse indices: left 0, right 1, middle 2, then additional buttons. */
    public static int mouseButtonIndex(int nativeButton) {
        //? if >=26.3 {
        /*return switch (nativeButton) {
            case 1 -> 0;
            case 2 -> 2;
            case 3 -> 1;
            default -> nativeButton - 1;
        };
        *///?} else {
        return nativeButton;
        //?}
    }

    public static long windowHandle(net.minecraft.class_1041 window) {
        //? if >=26.1 {
        /*return window.handle();
        *///?} else {
        return window.method_4490();
        //?}
    }

    public static net.minecraft.class_243 cameraPosition(net.minecraft.class_4184 camera) {
        //? if >=26.1 {
        /*return camera.position();
        *///?} else {
        return camera.method_19326();
        //?}
    }

    public static void putVertex(class_4587.class_4665 pose, class_4588 consumer, float x, float y, float z, int red, int green, int blue, int alpha) {
        //? if <1.21 {
        /*consumer.vertex(pose.pose(), x, y, z).color(red, green, blue, alpha).endVertex();
        *///?} else {
        consumer.method_56824(pose, x, y, z).method_1336(red, green, blue, alpha);
        //?}
    }
}
