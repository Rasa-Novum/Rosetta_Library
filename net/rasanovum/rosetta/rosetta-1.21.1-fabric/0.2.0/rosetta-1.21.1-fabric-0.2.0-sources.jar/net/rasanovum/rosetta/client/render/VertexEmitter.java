package net.rasanovum.rosetta.client.render;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;

/** Emits full-bright textured vertices with an explicit normal. */
public final class VertexEmitter {
    private static final int FULL_BRIGHT = 0xF000F0;

    private VertexEmitter() {}

    public static void fullBright(class_4587.class_4665 pose, class_4588 consumer,
                                  float x, float y, float z, float red, float green, float blue, float alpha,
                                  float u, float v, float normalX, float normalY, float normalZ) {
        //? if <1.21 {
        /*consumer.vertex(pose.pose(), x, y, z).color(red, green, blue, alpha).uv(u, v)
                .overlayCoords(0).uv2(FULL_BRIGHT).normal(pose.normal(), normalX, normalY, normalZ).endVertex();
        *///?} else {
        consumer.method_56824(pose, x, y, z).method_22915(red, green, blue, alpha).method_22913(u, v)
                .method_22922(class_4608.field_21444).method_60803(FULL_BRIGHT).method_60831(pose, normalX, normalY, normalZ);
        //?}
    }

    public static void fullBright(class_4588 consumer,
                                  float x, float y, float z, float red, float green, float blue, float alpha,
                                  float u, float v, float normalX, float normalY, float normalZ) {
        //? if <1.21 {
        /*consumer.vertex(x, y, z).color(red, green, blue, alpha).uv(u, v)
                .overlayCoords(0).uv2(FULL_BRIGHT).normal(normalX, normalY, normalZ).endVertex();
        *///?} else {
        consumer.method_22912(x, y, z).method_22915(red, green, blue, alpha).method_22913(u, v)
                .method_22922(class_4608.field_21444).method_60803(FULL_BRIGHT).method_22914(normalX, normalY, normalZ);
        //?}
    }
}
