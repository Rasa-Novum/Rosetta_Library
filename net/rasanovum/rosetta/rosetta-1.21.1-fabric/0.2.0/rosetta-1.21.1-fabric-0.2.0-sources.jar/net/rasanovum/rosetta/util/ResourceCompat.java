package net.rasanovum.rosetta.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_2960;
import net.minecraft.class_3300;

/** Resource enumeration and streams whose close also releases legacy metadata streams. */
public final class ResourceCompat {
    private ResourceCompat() {}

    public static List<class_2960> list(class_3300 manager, String folder, Predicate<class_2960> filter) {
        //? if <1.19 {
        /*return manager.listResources(folder, name -> true).stream().filter(filter).toList();
        *///?} else {
        return manager.method_14488(folder, filter::test).keySet().stream().toList();
        //?}
    }

    public static InputStream open(class_3300 manager, class_2960 location) throws IOException {
        //? if <1.19 {
        /*var resource = manager.getResource(location);
        return new FilterInputStream(resource.getInputStream()) {
            @Override
            public void close() throws IOException {
                resource.close();
            }
        };
        *///?} else {
        return manager.open(location);
        //?}
    }
    public static String blockTagDirectory() {
        //? if <1.21 {
        /*return "tags/blocks";
        *///?} else {
        return "tags/block";
        //?}
    }
}
