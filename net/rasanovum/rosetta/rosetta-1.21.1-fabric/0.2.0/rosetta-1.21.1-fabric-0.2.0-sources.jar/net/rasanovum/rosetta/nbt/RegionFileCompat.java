package net.rasanovum.rosetta.nbt;

import java.io.IOException;
import java.nio.file.Path;
import net.minecraft.class_1937;
import net.minecraft.class_2861;
import net.minecraft.class_5321;
import net.minecraft.class_9240;

/** Region-file construction across the storage metadata API change. */
public final class RegionFileCompat {
    private RegionFileCompat() {}

    public static class_2861 open(String worldName, class_5321<class_1937> dimension, Path path, Path folder) throws IOException {
        //? if >1.20.1 {
        return new class_2861(new class_9240(worldName, dimension, "chunk"), path, folder, true);
        //?} else {
        /*return new RegionFile(path, folder, true);
        *///?}
    }
}
