package net.rasanovum.rosetta.nbt;

import java.io.IOException;
import java.nio.file.Path;
import net.minecraft.class_1937;
import net.minecraft.class_2861;
import net.minecraft.class_5321;

/** Region-file construction across the storage metadata API change. */
public final class RegionFileCompat {
    private RegionFileCompat() {}

    public static class_2861 open(String worldName, class_5321<class_1937> dimension, Path path, Path folder) throws IOException {
        //? if >1.20.1 {
        /*return new RegionFile(new RegionStorageInfo(worldName, dimension, "chunk"), path, folder, true);
        *///?} else {
        return new class_2861(path, folder, true);
        //?}
    }
}
