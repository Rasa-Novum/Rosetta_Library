package net.rasanovum.rosetta.client.gui;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5481;
import net.minecraft.class_7833;

/** GUI drawing helpers. */
public class GuiCompat {

    private GuiCompat() {}

    //? if <1.20 {
    /*public static void confirmLink(String url) {
        Minecraft minecraft = Minecraft.getInstance();
        var parent = minecraft.screen;
        minecraft.setScreen(new net.minecraft.client.gui.screens.ConfirmLinkScreen(confirmed -> {
            if (confirmed) net.minecraft.Util.getPlatform().openUri(url);
            minecraft.setScreen(parent);
        }, url, true));
    }

    public static void renderItem(GuiGraphics graphics, net.minecraft.world.item.ItemStack stack, int x, int y) {
        Minecraft.getInstance().getItemRenderer().renderAndDecorateItem(stack, x, y);
    }
    *///?}

    /** Moves a vanilla screen control without requiring a Rosetta widget subclass. */
    public static void moveWidget(net.minecraft.class_437 screen, class_2561 message, int y) {
        for (var child : screen.method_25396()) {
            if (child instanceof class_339 widget && widget.method_25369().equals(message)) {
                //? if <1.20 {
                /*widget.y = y;
                *///?} else {
                widget.method_46419(y);
                //?}
            }
        }
    }

    //? if <1.20 {
    /*private static final java.util.Deque<int[]> SCISSORS = new java.util.ArrayDeque<>();

    private static class LegacyGradient extends net.minecraft.client.gui.GuiComponent {
        static void draw(GuiGraphics pose, int x1, int y1, int x2, int y2, int top, int bottom) {
            new LegacyGradient().fillGradient(pose, x1, y1, x2, y2, top, bottom);
        }
    }
    *///?}

    public static void fill(class_332 graphics, int x1, int y1, int x2, int y2, int color) {
        //? if <1.20 {
        /*net.minecraft.client.gui.GuiComponent.fill(graphics, x1, y1, x2, y2, color);
        *///?} else {
        graphics.method_25294(x1, y1, x2, y2, color);
        //?}
    }

    public static void fillGradient(class_332 graphics, int x1, int y1, int x2, int y2, int top, int bottom) {
        //? if <1.20 {
        /*LegacyGradient.draw(graphics, x1, y1, x2, y2, top, bottom);
        *///?} else {
        graphics.method_25296(x1, y1, x2, y2, top, bottom);
        //?}
    }

    public static void flush(class_332 graphics) {
        //? if <1.20 {
        /*Minecraft.getInstance().renderBuffers().bufferSource().endBatch();
        *///?} else if <26.1 {
        graphics.method_51452();
        //?}
    }

    public static void enableScissor(class_332 graphics, int x1, int y1, int x2, int y2) {
        //? if <1.20 {
        /*if (!SCISSORS.isEmpty()) {
            int[] parent = SCISSORS.peek();
            x1 = Math.max(x1, parent[0]);
            y1 = Math.max(y1, parent[1]);
            x2 = Math.min(x2, parent[2]);
            y2 = Math.min(y2, parent[3]);
        }
        SCISSORS.push(new int[] {x1, y1, x2, y2});
        applyLegacyScissor();
        *///?} else {
        graphics.method_44379(x1, y1, x2, y2);
        //?}
    }

    public static void disableScissor(class_332 graphics) {
        //? if <1.20 {
        /*if (!SCISSORS.isEmpty()) {
            SCISSORS.pop();
        }
        applyLegacyScissor();
        *///?} else {
        graphics.method_44380();
        //?}
    }

    //? if <1.20 {
    /*private static void applyLegacyScissor() {
        if (SCISSORS.isEmpty()) {
            RenderSystem.disableScissor();
            return;
        }
        int[] bounds = SCISSORS.peek();
        var window = Minecraft.getInstance().getWindow();
        double scale = window.getGuiScale();
        RenderSystem.enableScissor((int) (bounds[0] * scale), (int) (window.getHeight() - bounds[3] * scale),
                Math.max(0, (int) ((bounds[2] - bounds[0]) * scale)),
                Math.max(0, (int) ((bounds[3] - bounds[1]) * scale)));
    }
    *///?}

    public static void drawString(class_332 guiGraphics, class_327 font, String text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x, y, opaque(color), shadow);
        *///?} else {
        //? if <1.20 {
        /*if (shadow) {
            font.drawShadow(guiGraphics, text, x, y, color);
        } else {
            font.draw(guiGraphics, text, x, y, color);
        }
        *///?} else {
        guiGraphics.method_51433(font, text, x, y, color, shadow);
        //?}
        //?}
    }

    public static void drawString(class_332 guiGraphics, class_327 font, class_2561 text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x, y, opaque(color), shadow);
        *///?} else {
        //? if <1.20 {
        /*if (shadow) {
            font.drawShadow(guiGraphics, text, x, y, color);
        } else {
            font.draw(guiGraphics, text, x, y, color);
        }
        *///?} else {
        guiGraphics.method_51439(font, text, x, y, color, shadow);
        //?}
        //?}
    }

    public static void drawWidgetString(class_332 guiGraphics, class_339 widget, class_327 font, class_2561 text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text.copy().withStyle(style -> style.withColor(color & 0xFFFFFF)), x, y, opaque(color), shadow);
        *///?} else {
        //? if <1.20 {
        /*if (shadow) {
            font.drawShadow(guiGraphics, text, x, y, color);
        } else {
            font.draw(guiGraphics, text, x, y, color);
        }
        *///?} else {
        guiGraphics.method_51439(font, text, x, y, color, shadow);
        //?}
        //?}
    }

    public static void drawWidgetString(class_332 guiGraphics, class_339 widget, class_327 font, String text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, Component.literal(text).withStyle(style -> style.withColor(color & 0xFFFFFF)), x, y, opaque(color), shadow);
        *///?} else {
        //? if <1.20 {
        /*if (shadow) {
            font.drawShadow(guiGraphics, text, x, y, color);
        } else {
            font.draw(guiGraphics, text, x, y, color);
        }
        *///?} else {
        guiGraphics.method_51433(font, text, x, y, color, shadow);
        //?}
        //?}
    }

    public static void drawString(class_332 guiGraphics, class_327 font, class_5481 text, int x, int y, int color, boolean shadow) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x, y, opaque(color), shadow);
        *///?} else {
        //? if <1.20 {
        /*if (shadow) {
            font.drawShadow(guiGraphics, text, x, y, color);
        } else {
            font.draw(guiGraphics, text, x, y, color);
        }
        *///?} else {
        guiGraphics.method_51430(font, text, x, y, color, shadow);
        //?}
        //?}
    }

    public static void drawCenteredString(class_332 guiGraphics, class_327 font, class_2561 text, int x, int y, int color) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x - font.width(text) / 2, y, opaque(color), false);
        *///?} else {
        //? if <1.20 {
        /*net.minecraft.client.gui.GuiComponent.drawCenteredString(guiGraphics, font, text, x, y, color);
        *///?} else {
        guiGraphics.method_27534(font, text, x, y, color);
        //?}
        //?}
    }

    public static void drawCenteredString(class_332 guiGraphics, class_327 font, String text, int x, int y, int color) {
        //? if >=26.1 {
        /*guiGraphics.text(font, text, x - font.width(text) / 2, y, opaque(color), false);
        *///?} else {
        //? if <1.20 {
        /*net.minecraft.client.gui.GuiComponent.drawCenteredString(guiGraphics, font, text, x, y, color);
        *///?} else {
        guiGraphics.method_25300(font, text, x, y, color);
        //?}
        //?}
    }

    public static void hLine(class_332 guiGraphics, int x1, int x2, int y, int color) {
        //? if >=26.1 {
        /*guiGraphics.horizontalLine(x1, x2, y, color);
        *///?} else {
        //? if <1.20 {
        /*net.minecraft.client.gui.GuiComponent.fill(guiGraphics, Math.min(x1, x2), y, Math.max(x1, x2) + 1, y + 1, color);
        *///?} else {
        guiGraphics.method_25292(x1, x2, y, color);
        //?}
        //?}
    }

    public static void vLine(class_332 guiGraphics, int x, int y1, int y2, int color) {
        //? if >=26.1 {
        /*guiGraphics.verticalLine(x, y1, y2, color);
        *///?} else {
        //? if <1.20 {
        /*net.minecraft.client.gui.GuiComponent.fill(guiGraphics, x, Math.min(y1, y2) + 1, x + 1, Math.max(y1, y2), color);
        *///?} else {
        guiGraphics.method_25301(x, y1, y2, color);
        //?}
        //?}
    }

    public static void renderOutline(class_332 guiGraphics, int x, int y, int width, int height, int color) {
        //? if >=26.1 {
        /*guiGraphics.outline(x, y, width, height, color);
        *///?} else {
        //? if <1.20 {
        /*hLine(guiGraphics, x, x + width - 1, y, color);
        hLine(guiGraphics, x, x + width - 1, y + height - 1, color);
        vLine(guiGraphics, x, y, y + height - 1, color);
        vLine(guiGraphics, x + width - 1, y, y + height - 1, color);
        *///?} else {
        guiGraphics.method_49601(x, y, width, height, color);
        //?}
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int u, int v, int width, int height, int texWidth, int texHeight) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, u, v, width, height, texWidth, texHeight);
        *///?} else {
        //? if <1.20 {
        /*com.mojang.blaze3d.systems.RenderSystem.setShaderTexture(0, texture);
        net.minecraft.client.gui.GuiComponent.blit(guiGraphics, x, y, (float) u, (float) v, width, height, texWidth, texHeight);
        *///?} else {
        guiGraphics.method_25290(texture, x, y, u, v, width, height, texWidth, texHeight);
        //?}
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int u, int v, int width, int height, int texWidth, int texHeight, int color) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, u, v, width, height, texWidth, texHeight, color);
        *///?} else {
        applyShaderColor(color);
        //? if <1.20 {
        /*com.mojang.blaze3d.systems.RenderSystem.setShaderTexture(0, texture);
        net.minecraft.client.gui.GuiComponent.blit(guiGraphics, x, y, (float) u, (float) v, width, height, texWidth, texHeight);
        *///?} else {
        guiGraphics.method_25290(texture, x, y, u, v, width, height, texWidth, texHeight);
        //?}
        resetShaderColor();
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int width, int height, int u, int v, int uWidth, int vHeight, int texWidth, int texHeight) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, (float) u, (float) v, width, height, uWidth, vHeight, texWidth, texHeight);
        *///?} else {
        //? if <1.20 {
        /*com.mojang.blaze3d.systems.RenderSystem.setShaderTexture(0, texture);
        net.minecraft.client.gui.GuiComponent.blit(guiGraphics, x, y, width, height, (float) u, (float) v, uWidth, vHeight, texWidth, texHeight);
        *///?} else {
        guiGraphics.method_25293(texture, x, y, width, height, u, v, uWidth, vHeight, texWidth, texHeight);
        //?}
        //?}
    }

    public static void blit(class_332 guiGraphics, class_2960 texture, int x, int y, int width, int height, int u, int v, int uWidth, int vHeight, int texWidth, int texHeight, int color) {
        //? if >=26.1 {
        /*guiGraphics.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, texture, x, y, (float) u, (float) v, width, height, uWidth, vHeight, texWidth, texHeight, color);
        *///?} else {
        applyShaderColor(color);
        //? if <1.20 {
        /*com.mojang.blaze3d.systems.RenderSystem.setShaderTexture(0, texture);
        net.minecraft.client.gui.GuiComponent.blit(guiGraphics, x, y, width, height, (float) u, (float) v, uWidth, vHeight, texWidth, texHeight);
        *///?} else {
        guiGraphics.method_25293(texture, x, y, width, height, u, v, uWidth, vHeight, texWidth, texHeight);
        //?}
        resetShaderColor();
        //?}
    }

    public static void renderTooltip(class_332 guiGraphics, class_327 font, class_2561 tooltip, int x, int y) {
        //? if >=26.1 {
        /*guiGraphics.setTooltipForNextFrame(font, tooltip, x, y);
        *///?} else {
        //? if <1.20 {
        /*legacyTooltipScreen().renderTooltip(guiGraphics, tooltip, x, y);
        *///?} else {
        guiGraphics.method_51438(font, tooltip, x, y);
        //?}
        //?}
    }

    public static void renderComponentTooltip(class_332 guiGraphics, class_327 font, List<class_2561> tooltip, int x, int y) {
        //? if >=26.1 {
        /*guiGraphics.setComponentTooltipForNextFrame(font, tooltip, x, y);
        *///?} else {
        //? if <1.20 {
        /*legacyTooltipScreen().renderComponentTooltip(guiGraphics, tooltip, x, y);
        *///?} else {
        guiGraphics.method_51434(font, tooltip, x, y);
        //?}
        //?}
    }

    public static void renderComponentHoverEffect(class_332 guiGraphics, class_327 font, class_2583 style, int x, int y) {
        if (style == null || style.method_10969() == null) return;

        //? if >=26.1 {
        /*if (style.getHoverEvent() instanceof HoverEvent.ShowText showText) {
            guiGraphics.setTooltipForNextFrame(font, showText.value(), x, y);
        }
        *///?} else {
        //? if <1.20 {
        /*legacyTooltipScreen().hover(guiGraphics, style, x, y);
        *///?} else {
        guiGraphics.method_51441(font, style, x, y);
        //?}
        //?}
    }

    public static class_2583 firstHoverStyle(class_2561 component) {
        for (class_2561 sibling : component.method_36136(net.minecraft.class_2583.field_24360)) {
            class_2583 style = sibling.method_10866();
            if (style.method_10969() != null) return style;
        }
        return null;
    }

    public static void pushPose(class_332 guiGraphics) {
        //? if >=26.1 {
        /*guiGraphics.pose().pushMatrix();
        *///?} else {
        //? if <1.20 {
        /*guiGraphics.pushPose();
        *///?} else {
        guiGraphics.method_51448().method_22903();
        //?}
        //?}
    }

    public static void popPose(class_332 guiGraphics) {
        //? if >=26.1 {
        /*guiGraphics.pose().popMatrix();
        *///?} else {
        //? if <1.20 {
        /*guiGraphics.popPose();
        *///?} else {
        guiGraphics.method_51448().method_22909();
        //?}
        //?}
    }

    public static void translate(class_332 guiGraphics, float x, float y) {
        //? if >=26.1 {
        /*guiGraphics.pose().translate(x, y);
        *///?} else {
        //? if <1.20 {
        /*guiGraphics.translate(x, y, 0);
        *///?} else {
        guiGraphics.method_51448().method_46416(x, y, 0);
        //?}
        //?}
    }

    public static void scale(class_332 guiGraphics, float sx, float sy) {
        //? if >=26.1 {
        /*guiGraphics.pose().scale(sx, sy);
        *///?} else {
        //? if <1.20 {
        /*guiGraphics.scale(sx, sy, 1.0f);
        *///?} else {
        guiGraphics.method_51448().method_22905(sx, sy, 1.0f);
        //?}
        //?}
    }

    public static void rotateDegrees(class_332 guiGraphics, float degrees) {
        //? if >=26.1 {
        /*guiGraphics.pose().rotate((float) Math.toRadians(degrees));
        *///?} else {
        //? if <1.20 {
        /*guiGraphics.mulPose(Vector3f.ZP.rotationDegrees(degrees));
        *///?} else {
        guiGraphics.method_51448().method_22907(class_7833.field_40718.rotationDegrees(degrees));
        //?}
        //?}
    }

    public static void nextStratum(class_332 guiGraphics) {
        //? if >=26.1
        /*guiGraphics.nextStratum();*/
    }

    public static void enableBlend() {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
    }

    public static void disableBlend() {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.disableBlend();
    }

    public static void setShaderColor(float r, float g, float b, float a) {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(r, g, b, a);
    }

    public static void defaultBlendFunc() {
        //? if <26.1
        com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();
    }

    public static int argb(float r, float g, float b, float a) {
        int ai = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
        int ri = Math.max(0, Math.min(255, Math.round(r * 255.0f)));
        int gi = Math.max(0, Math.min(255, Math.round(g * 255.0f)));
        int bi = Math.max(0, Math.min(255, Math.round(b * 255.0f)));
        return (ai << 24) | (ri << 16) | (gi << 8) | bi;
    }

    //? if <1.20 {
    /*private static LegacyTooltipScreen legacyTooltipScreen() {
        var minecraft = net.minecraft.client.Minecraft.getInstance();
        var screen = new LegacyTooltipScreen();
        screen.init(minecraft, minecraft.getWindow().getGuiScaledWidth(), minecraft.getWindow().getGuiScaledHeight());
        return screen;
    }

    private static final class LegacyTooltipScreen extends net.minecraft.client.gui.screens.Screen {
        private LegacyTooltipScreen() {
            super(Component.empty());
        }

        private void hover(com.mojang.blaze3d.vertex.PoseStack pose, Style style, int x, int y) {
            renderComponentHoverEffect(pose, style, x, y);
        }
    }
    *///?}

    private static int withAlpha(int color, float alpha) {
        int sourceAlpha = (color >>> 24) & 0xFF;
        if (sourceAlpha == 0) sourceAlpha = 0xFF;
        int combinedAlpha = Math.max(0, Math.min(255, Math.round(sourceAlpha * alpha)));
        return (combinedAlpha << 24) | (color & 0xFFFFFF);
    }

    private static int opaque(int color) {
        return ((color >>> 24) & 0xFF) == 0 ? color | 0xFF000000 : color;
    }

    private static void applyShaderColor(int color) {
        float a = ((color >>> 24) & 0xFF) / 255.0f;
        float r = ((color >>> 16) & 0xFF) / 255.0f;
        float g = ((color >>> 8) & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        enableBlend();
        setShaderColor(r, g, b, a);
    }

    private static void resetShaderColor() {
        setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        disableBlend();
    }
    /** Presents a tooltip after the screen contents on legacy Forge. */
    public static void scheduleTooltip(class_332 graphics, class_327 font, class_2561 tooltip, int x, int y) {
        //? if forge && <1.20 {
        /*net.rasanovum.rosetta.client.gui.legacy.LegacyTooltips.schedule(tooltip, x, y);
        *///?} else {
        renderTooltip(graphics, font, tooltip, x, y);
        //?}
    }

    public static void renderWidget(net.minecraft.class_339 widget,
                                    class_332 graphics, int mouseX, int mouseY, float partialTick) {
        //? if >=26.1 {
        /*widget.extractRenderState(graphics, mouseX, mouseY, partialTick);
        *///?} else {
        widget.method_25394(graphics, mouseX, mouseY, partialTick);
        //?}
    }
}
