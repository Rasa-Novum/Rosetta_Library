package net.rasanovum.rosetta.util;

import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2839;
import net.minecraft.class_2843;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3754;
import net.minecraft.class_5284;
import net.minecraft.class_5321;
import net.minecraft.class_6544;
import net.minecraft.class_6880;
import net.minecraft.class_7138;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Optional;

/** Biome sampling helpers. */
public final class BiomeCompat {
    private BiomeCompat() {}

    public static class_5284 generatorSettings(class_3754 generator) {
        //? if <1.19 {
        /*return ((net.rasanovum.rosetta.mixin.LegacyNoiseGeneratorAccessor) generator).rosetta$settings().value();
        *///?} else {
        return generator.method_41541().comp_349();
        //?}
    }

    public static class_6544.class_6552 climateSampler(class_3218 level) {
        //? if <1.19 {
        /*return level.getChunkSource().getGenerator().climateSampler();
        *///?} else {
        return climateSampler(level.method_14178().method_41248());
        //?}
    }

    //? if >=1.19 {
    public static class_6544.class_6552 climateSampler(class_7138 state) {
        //? if >=26.3 {
        /*return state.createClimateSampler(net.minecraft.world.level.levelgen.densityfunction.SamplerContext.EMPTY_UNCACHED);
        *///?} else {
        return state.method_42371();
        //?}
    }

    //?}

    @FunctionalInterface
    public interface Sampler {
        class_6880<class_1959> getNoiseBiome(int x, int y, int z);
    }

    /** Coordinates are in quart-biome units. Reuse the resolver for repeated samples. */
    public static Sampler resolver(class_1966 source,
            class_6544.class_6552 sampler) {
        //? if >=26.3 {
        /*return source.createResolver(sampler)::getNoiseBiome;
        *///?} else {
        return (x, y, z) -> source.method_38109(x, y, z, sampler);
        //?}
    }

    public static class_2378<class_1959> registry(MinecraftServer server) {
        //? if >=26.1 {
        /*return server.registryAccess().lookupOrThrow(Registries.BIOME);
        *///?} else {
        //? if <1.19.3 {
        /*return server.registryAccess().registryOrThrow(Registry.BIOME_REGISTRY);
        *///?} else {
        return server.method_30611().method_30530(class_7924.field_41236);
        //?}
        //?}
    }

    public static class_2378<class_1959> registry(class_3218 level) {
        //? if >=26.1 {
        /*return level.registryAccess().lookupOrThrow(Registries.BIOME);
        *///?} else {
        //? if <1.19.3 {
        /*return level.registryAccess().registryOrThrow(Registry.BIOME_REGISTRY);
        *///?} else {
        return level.method_30349().method_30530(class_7924.field_41236);
        //?}
        //?}
    }

    public static Optional<class_6880.class_6883<class_1959>> holder(class_2378<class_1959> registry, class_2960 location) {
        //? if >=26.1 {
        /*return registry.get(location);
        *///?} else {
        //? if <1.19.3 {
        /*return registry.getHolder(ResourceKey.create(Registry.BIOME_REGISTRY, location))
                .filter(holder -> holder instanceof Holder.Reference<Biome>)
                .map(holder -> (Holder.Reference<Biome>) holder);
        *///?} else {
        return registry.method_40264(class_5321.method_29179(class_7924.field_41236, location));
        //?}
        //?}
    }

    public static List<class_6880<class_1959>> holders(class_2378<class_1959> registry) {
        //? if >=26.1 {
        /*return registry.entrySet().stream().map(entry -> registry.wrapAsHolder(entry.getValue())).toList();
        *///?} else {
        return registry.method_40270().map(holder -> (class_6880<class_1959>) holder).toList();
        //?}
    }

    public static class_2839 createProtoChunk(class_3218 level) {
        //? if >=26.1 {
        /*return new ProtoChunk(new ChunkPos(0, 0), UpgradeData.EMPTY, level, level.palettedContainerFactory(), null);
        *///?} else {
        return new class_2839(new class_1923(0, 0), class_2843.field_12950, level, registry(level), null);
        //?}
    }

    public static void setBlockState(class_2839 chunk, class_2338 pos, class_2680 state) {
        //? if >=26.1 {
        /*chunk.setBlockState(pos, state, 0);
        *///?} else {
        chunk.method_12010(pos, state, false);
        //?}
    }

    public static boolean coldEnoughToSnow(class_1959 biome, class_2338 pos, int seaLevel) {
        //? if >=26.1 {
        /*return biome.coldEnoughToSnow(pos, seaLevel);
        *///?} else {
        return biome.method_33599(pos);
        //?}
    }
}
