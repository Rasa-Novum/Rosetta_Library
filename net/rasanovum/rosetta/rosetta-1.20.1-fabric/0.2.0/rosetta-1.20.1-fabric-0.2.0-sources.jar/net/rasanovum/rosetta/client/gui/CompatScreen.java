package net.rasanovum.rosetta.client.gui;

import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;

/** Opt-in vanilla adapter with stable subclass hooks. */
public abstract class CompatScreen extends net.minecraft.class_437 {
    protected CompatScreen(class_2561 title) { super(title); }

    //? if >=26.1 {
    /*@Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
        return onMouseClick(new MouseInput(event, doubled), () -> super.mouseClicked(event, doubled));
    }
    *///?} else {
    @Override
    public boolean method_25402(double x, double y, int button) {
        return onMouseClick(new MouseInput(x, y, button), () -> super.method_25402(x, y, button));
    }
    //?}

    protected boolean onMouseClick(MouseInput input, BooleanSupplier next) {
        return next.getAsBoolean();
    }

    //? if >=26.1 {
    /*@Override
    public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent event, double dragX, double dragY) {
        return onMouseDrag(new MouseInput(event, false), dragX, dragY, () -> super.mouseDragged(event, dragX, dragY));
    }
    *///?} else {
    @Override
    public boolean method_25403(double x, double y, int button, double dragX, double dragY) {
        return onMouseDrag(new MouseInput(x, y, button), dragX, dragY, () -> super.method_25403(x, y, button, dragX, dragY));
    }
    //?}

    protected boolean onMouseDrag(MouseInput input, double dragX, double dragY, BooleanSupplier next) {
        return next.getAsBoolean();
    }

    //? if <1.20.2 {
    @Override
    public boolean method_25401(double x, double y, double scrollY) {
        return onMouseScroll(x, y, 0, scrollY, () -> super.method_25401(x, y, scrollY));
    }
    //?} else {
    /*@Override
    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        return onMouseScroll(x, y, scrollX, scrollY, () -> super.mouseScrolled(x, y, scrollX, scrollY));
    }
    *///?}

    protected boolean onMouseScroll(double x, double y, double scrollX, double scrollY, BooleanSupplier next) {
        return next.getAsBoolean();
    }
}
