package net.rasanovum.rosetta.client.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/** Opt-in vanilla adapter with stable subclass hooks. */
public abstract class CompatButton extends class_4185 {
    protected CompatButton(int x, int y, int width, int height, class_2561 text, class_4241 press) {
        super(x, y, width, height, text, press, field_40754);
    }

    //? if >=26.1 {
    /*@Override
    public void extractContents(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    *///?} else {
    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    //?}

    protected abstract void drawWidget(class_332 graphics, int mouseX, int mouseY, float partialTick);

}
