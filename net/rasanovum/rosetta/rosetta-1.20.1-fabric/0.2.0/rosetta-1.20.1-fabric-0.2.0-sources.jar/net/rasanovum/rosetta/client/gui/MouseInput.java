package net.rasanovum.rosetta.client.gui;

import net.minecraft.class_364;
import net.rasanovum.rosetta.util.ClientCompat;
//? if >=26.1 {
/*import net.minecraft.client.input.MouseButtonEvent;
*///?}

/** A mouse event with stable button indices; forwarding retains the original native event. */
public final class MouseInput {
    private final double x;
    private final double y;
    private final int button;
    private final int modifiers;
    private final boolean doubled;
    //? if >=26.1 {
    /*private final MouseButtonEvent event;

    public MouseInput(MouseButtonEvent event, boolean doubled) {
        this.event = event;
        this.x = event.x();
        this.y = event.y();
        this.button = ClientCompat.mouseButtonIndex(event.button());
        this.modifiers = event.modifiers();
        this.doubled = doubled;
    }
    *///?} else {
    public MouseInput(double x, double y, int button) {
        this.x = x;
        this.y = y;
        this.button = button;
        this.modifiers = (net.minecraft.class_437.method_25442() ? 1 : 0)
                | (net.minecraft.class_437.method_25441() ? 2 : 0)
                | (net.minecraft.class_437.method_25443() ? 4 : 0);
        this.doubled = false;
    }
    //?}

    public double x() { return x; }
    public double y() { return y; }
    public int button() { return button; }
    public int modifiers() { return modifiers; }
    public boolean doubled() { return doubled; }

    public boolean click(class_364 listener) {
        //? if >=26.1 {
        /*return listener.mouseClicked(event, doubled);
        *///?} else {
        return listener.method_25402(x, y, button);
        //?}
    }
}
