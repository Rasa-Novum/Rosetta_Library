package net.rasanovum.rosetta.util;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.class_1322;
import net.minecraft.class_1324;

/** Attribute modifier helpers. */
public final class AttributeCompat {
    private AttributeCompat() {}

    //? if >=1.21 {
    /*public static AttributeModifier movementSpeedMultiplier(String modifierKey, double amount) {
        return new AttributeModifier(RegistryCompat.getLocation(modifierKey), amount, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
    }
    *///?} else {
    public static class_1322 movementSpeedMultiplier(String modifierKey, double amount) {
        return new class_1322(attributeModifierUuid(modifierKey), modifierKey, amount, class_1322.class_1323.field_6331);
    }
    //?}

    public static boolean hasModifier(class_1324 attribute, String modifierKey) {
        //? if >=1.21 {
        /*return attribute.getModifier(RegistryCompat.getLocation(modifierKey)) != null;
        *///?} else {
        return attribute.method_6199(attributeModifierUuid(modifierKey)) != null;
        //?}
    }

    public static void removeModifier(class_1324 attribute, String modifierKey) {
        //? if >=1.21 {
        /*attribute.removeModifier(RegistryCompat.getLocation(modifierKey));
        *///?} else {
        attribute.method_6200(attributeModifierUuid(modifierKey));
        //?}
    }

    public static String canonicalModifierKey(String modifierKey) {
        //? if >=1.21 {
        /*return RegistryCompat.getLocation(modifierKey).toString();
        *///?} else {
        return attributeModifierUuid(modifierKey).toString();
        //?}
    }

    public static String modifierKey(class_1322 modifier) {
        //? if >=1.21 {
        /*return modifier.id().toString();
        *///?} else {
        return modifier.method_6189().toString();
        //?}
    }

    public static double calculateAttributeValueSkipping(class_1324 attribute, Predicate<class_1322> skipModifier) {
        double baseValue = attribute.method_6201();
        class_1322[] modifiers = attribute.method_6195().toArray(class_1322[]::new);
        for (int i = 0; i < modifiers.length; i++) {
            if (skipModifier.test(modifiers[i])) modifiers[i] = null;
        }

        //? if >=1.21 {
        /*for (AttributeModifier modifier : modifiers) {
            if (modifier != null && modifier.operation() == AttributeModifier.Operation.ADD_VALUE) baseValue += modifier.amount();
        }
        double value = baseValue;
        for (AttributeModifier modifier : modifiers) {
            if (modifier != null && modifier.operation() == AttributeModifier.Operation.ADD_MULTIPLIED_BASE) value += baseValue * modifier.amount();
        }
        for (AttributeModifier modifier : modifiers) {
            if (modifier != null && modifier.operation() == AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL) value *= 1.0D + modifier.amount();
        }
        return attribute.getAttribute().value().sanitizeValue(value);
        *///?} else {
        for (class_1322 modifier : modifiers) {
            if (modifier != null && modifier.method_6182() == class_1322.class_1323.field_6328) baseValue += modifier.method_6186();
        }
        double value = baseValue;
        for (class_1322 modifier : modifiers) {
            if (modifier != null && modifier.method_6182() == class_1322.class_1323.field_6330) value += baseValue * modifier.method_6186();
        }
        for (class_1322 modifier : modifiers) {
            if (modifier != null && modifier.method_6182() == class_1322.class_1323.field_6331) value *= 1.0D + modifier.method_6186();
        }
        return attribute.method_6198().method_6165(value);
        //?}
    }

    //? if <1.21 {
    private static UUID attributeModifierUuid(String modifierKey) {
        return UUID.nameUUIDFromBytes(modifierKey.getBytes(StandardCharsets.UTF_8));
    }
    //?}
    public static double amount(class_1322 modifier) {
        //? if >=1.21 {
        /*return modifier.amount();
        *///?} else {
        return modifier.method_6186();
        //?}
    }
}
