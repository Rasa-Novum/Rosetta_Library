package net.rasanovum.rosetta.client.gui;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;

/** Opt-in vanilla adapter with stable subclass hooks. */
public abstract class CompatEditBox extends class_342 {
    protected CompatEditBox(net.minecraft.class_327 font, int x, int y, int width, int height, class_2561 text) { super(font, x, y, width, height, text); }

    //? if >=26.1 {
    /*@Override
    public void extractWidgetRenderState(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    *///?} else {
    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    //?}

    protected abstract void drawWidget(class_332 graphics, int mouseX, int mouseY, float partialTick);

}
