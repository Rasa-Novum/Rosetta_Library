package net.rasanovum.rosetta.client.render;

import net.minecraft.class_4587;
import net.minecraft.class_4588;

/** Emits full-bright textured vertices with an explicit normal. */
public final class VertexEmitter {
    private static final int FULL_BRIGHT = 0xF000F0;

    private VertexEmitter() {}

    public static void fullBright(class_4587.class_4665 pose, class_4588 consumer,
                                  float x, float y, float z, float red, float green, float blue, float alpha,
                                  float u, float v, float normalX, float normalY, float normalZ) {
        //? if <1.21 {
        consumer.method_22918(pose.method_23761(), x, y, z).method_22915(red, green, blue, alpha).method_22913(u, v)
                .method_22922(0).method_22916(FULL_BRIGHT).method_23763(pose.method_23762(), normalX, normalY, normalZ).method_1344();
        //?} else {
        /*consumer.addVertex(pose, x, y, z).setColor(red, green, blue, alpha).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(pose, normalX, normalY, normalZ);
        *///?}
    }

    public static void fullBright(class_4588 consumer,
                                  float x, float y, float z, float red, float green, float blue, float alpha,
                                  float u, float v, float normalX, float normalY, float normalZ) {
        //? if <1.21 {
        consumer.method_22912(x, y, z).method_22915(red, green, blue, alpha).method_22913(u, v)
                .method_22922(0).method_22916(FULL_BRIGHT).method_22914(normalX, normalY, normalZ).method_1344();
        //?} else {
        /*consumer.addVertex(x, y, z).setColor(red, green, blue, alpha).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(normalX, normalY, normalZ);
        *///?}
    }
}
