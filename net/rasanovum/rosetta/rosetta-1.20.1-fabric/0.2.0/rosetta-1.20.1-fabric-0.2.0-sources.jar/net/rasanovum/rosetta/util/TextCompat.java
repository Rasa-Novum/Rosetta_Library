package net.rasanovum.rosetta.util;

import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2588;
//?}
import org.jetbrains.annotations.Nullable;

public final class TextCompat {
    private TextCompat() {}

    /** Returns the translation key of the component itself, or null for other text. */
    public static @Nullable String translationKey(class_2561 component) {
        //? if <1.19 {
        /*return component instanceof TranslatableComponent text ? text.getKey() : null;
        *///?} else {
        return component.method_10851() instanceof class_2588 text ? text.method_11022() : null;
        //?}
    }
    public static class_2568 showText(class_2561 text) {
        //? if >=26.1 {
        /*return new HoverEvent.ShowText(text);
        *///?} else {
        return new class_2568(class_2568.class_5247.field_24342, text);
        //?}
    }
}
