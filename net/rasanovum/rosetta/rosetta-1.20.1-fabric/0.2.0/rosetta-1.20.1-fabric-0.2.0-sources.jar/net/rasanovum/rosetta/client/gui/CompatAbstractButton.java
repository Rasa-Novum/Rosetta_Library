package net.rasanovum.rosetta.client.gui;

//?}
import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4264;

/** Opt-in vanilla adapter with stable subclass hooks. */
public abstract class CompatAbstractButton extends class_4264 {
    protected CompatAbstractButton(int x, int y, int width, int height, class_2561 text) { super(x, y, width, height, text); }

    //? if >=26.1 {
    /*@Override
    public void extractContents(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    *///?} else {
    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        drawWidget(graphics, mouseX, mouseY, partialTick);
    }
    //?}

    protected abstract void drawWidget(class_332 graphics, int mouseX, int mouseY, float partialTick);

    //? if >=26.1 {
    /*@Override
    public void onPress(net.minecraft.client.input.InputWithModifiers input) {
        onPress();
    }
    *///?}

    public abstract void method_25306();

    //? if >=26.1 {
    /*@Override
    public void onClick(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
        onMouseActivate(() -> super.onClick(event, doubled));
    }
    *///?} else {
    @Override
    public void method_25348(double x, double y) {
        onMouseActivate(() -> super.method_25348(x, y));
    }
    //?}

    protected void onMouseActivate(Runnable next) {
        next.run();
    }

    //? if >=26.1 {
    /*@Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent event, boolean doubled) {
        return onMouseClick(new MouseInput(event, doubled), () -> super.mouseClicked(event, doubled));
    }
    *///?} else {
    @Override
    public boolean method_25402(double x, double y, int button) {
        return onMouseClick(new MouseInput(x, y, button), () -> super.method_25402(x, y, button));
    }
    //?}

    protected boolean onMouseClick(MouseInput input, BooleanSupplier next) {
        return next.getAsBoolean();
    }

    //? if >=26.1 {
    /*@Override
    public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent event) {
        return onMouseRelease(new MouseInput(event, false), () -> super.mouseReleased(event));
    }
    *///?} else {
    @Override
    public boolean method_25406(double x, double y, int button) {
        return onMouseRelease(new MouseInput(x, y, button), () -> super.method_25406(x, y, button));
    }
    //?}

    protected boolean onMouseRelease(MouseInput input, BooleanSupplier next) {
        return next.getAsBoolean();
    }

}
