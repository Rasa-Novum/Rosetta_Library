package net.rasanovum.rosetta.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.Identifier;

import java.util.function.Function;

public record PacketDefinition<T extends RosettaPacket>(
        Identifier id,
        Class<T> type,
        Function<FriendlyByteBuf, T> reader,
        RosettaNetwork.ServerboundHandler<T> serverboundHandler,
        RosettaNetwork.ClientboundHandler<T> clientboundHandler
) {
    public PacketDefinition {
        if ((serverboundHandler == null) == (clientboundHandler == null)) {
            throw new IllegalArgumentException("Exactly one packet handler direction is required");
        }
    }

    public static <T extends RosettaPacket> PacketDefinition<T> serverbound(
            Identifier id, Class<T> type, Function<FriendlyByteBuf, T> reader,
            RosettaNetwork.ServerboundHandler<T> handler
    ) {
        return new PacketDefinition<>(id, type, reader, handler, null);
    }

    public static <T extends RosettaPacket> PacketDefinition<T> clientbound(
            Identifier id, Class<T> type, Function<FriendlyByteBuf, T> reader,
            RosettaNetwork.ClientboundHandler<T> handler
    ) {
        return new PacketDefinition<>(id, type, reader, null, handler);
    }
}
