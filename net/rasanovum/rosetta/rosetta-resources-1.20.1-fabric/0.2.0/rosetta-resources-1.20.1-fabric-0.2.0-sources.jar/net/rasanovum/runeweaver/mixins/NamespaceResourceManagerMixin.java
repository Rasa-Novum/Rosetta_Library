package net.rasanovum.runeweaver.mixins;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2960;
import net.minecraft.class_3294;
import net.minecraft.class_3298;
import net.rasanovum.runeweaver.Runeweaver;
import net.rasanovum.runeweaver.hooks.NamespaceHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Mixin(class_3294.class)
public class NamespaceResourceManagerMixin {


    //? if <1.19 {
    /*@ModifyReturnValue(method = "getResources", at = @At("RETURN"))
    *///?} else {
    @ModifyReturnValue(method = "getResourceStack", at = @At("RETURN"))
    //?}
    private List<class_3298> runRuneweaverEvents(List<class_3298> original, @Local(argsOnly = true) class_2960 id) {
        return Runeweaver.processHook(new NamespaceHook(original, id));
    }

    //? if <1.19 {
    /*@ModifyReturnValue(method = "getResource", at = @At("RETURN"))
    private Resource runLegacyRuneweaverEvents(Resource original, ResourceLocation id) throws java.io.IOException {
        List<Resource> result = Runeweaver.processHook(new NamespaceHook(new ArrayList<>(List.of(original)), id));
        if (result.isEmpty()) {
            original.close();
            throw new java.io.FileNotFoundException(id.toString());
        }
        return result.get(0);
    }
    *///?} else {
    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    @ModifyReturnValue(method = "getResource", at = @At("RETURN"))
    private Optional<class_3298> runRuneweaverEvents(Optional<class_3298> original, class_2960 id) {
        if(original.isEmpty()) return Optional.empty();
        List<class_3298> result = Runeweaver.processHook(new NamespaceHook(new ArrayList<>(List.of(original.get())), id));
        return Optional.ofNullable(result.get(0));
    }
    //?}
}
