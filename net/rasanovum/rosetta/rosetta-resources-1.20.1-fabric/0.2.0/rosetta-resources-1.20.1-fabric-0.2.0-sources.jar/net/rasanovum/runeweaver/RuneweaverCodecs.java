package net.rasanovum.runeweaver;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_3298;
import net.rasanovum.runeweaver.util.interfaces.RuneweaverCodec;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

@SuppressWarnings("unused")
public interface RuneweaverCodecs {

    RuneweaverCodec<JsonElement> JSON_ELEMENT = new RuneweaverCodec<>() {
        @Override
        public String extensionAndDot() {
            return ".json";
        }

        @Override
        public JsonElement deserialize(class_3298 r) throws IOException {
            //? if <1.19 {
            /*return JsonParser.parseReader(new java.io.InputStreamReader(r.getInputStream(), java.nio.charset.StandardCharsets.UTF_8));
            *///?} else {
            return JsonParser.parseReader(r.method_43039());
            //?}
        }

        @Override
        public class_3298 serialize(class_3298 r, JsonElement x) {
            //? if <1.19 {
            /*return new net.rasanovum.runeweaver.util.LegacyResource(r, x.toString().getBytes());
            *///?} else if <1.19.3 {
            /*return new Resource(r.sourcePackId(), () -> new ByteArrayInputStream(x.toString().getBytes()), r::metadata);
            *///?} else {
            return new class_3298(r.method_45304(), () -> new ByteArrayInputStream(x.toString().getBytes()), r::method_14481);
            //?}
        }

        @Override
        public ByteArrayOutputStream export(JsonElement resource) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(new GsonBuilder().setPrettyPrinting().create().toJson(resource).getBytes());
            return baos;
        }
    };

    RuneweaverCodec<BufferedImage> PNG = new RuneweaverCodec<>() {
        @Override
        public String extensionAndDot() {
            return ".png";
        }

        @Override
        public BufferedImage deserialize(class_3298 r) throws IOException {
            return ImageIO.read(open(r));
        }

        @Override
        public class_3298 serialize(class_3298 r, BufferedImage x) throws IOException {
            //? if <1.19 {
            /*return new net.rasanovum.runeweaver.util.LegacyResource(r, bufferedImageToStream(x).toByteArray());
            *///?} else if <1.19.3 {
            /*return new Resource(r.sourcePackId(), () -> new ByteArrayInputStream(bufferedImageToStream(x).toByteArray()), r::metadata);
            *///?} else {
            return new class_3298(r.method_45304(), () -> new ByteArrayInputStream(bufferedImageToStream(x).toByteArray()), r::method_14481);
            //?}
        }

        @Override
        public ByteArrayOutputStream export(BufferedImage r) throws IOException {
            return bufferedImageToStream(r);
        }
    };

    RuneweaverCodec<class_2487> NBT = new RuneweaverCodec<>() {
        @Override
        public String extensionAndDot() {
            return ".nbt";
        }

        @Override
        public class_2487 deserialize(class_3298 r) throws IOException {
            //? if >1.20.1 {
            /*return NbtIo.readCompressed(open(r), NbtAccounter.unlimitedHeap());
            *///?} else {
            return class_2507.method_10629(open(r));
            //?}
        }

        @Override
        public class_3298 serialize(class_3298 r, class_2487 x) throws IOException {
            //? if <1.19 {
            /*return new net.rasanovum.runeweaver.util.LegacyResource(r, nbtToStream(x).toByteArray());
            *///?} else if <1.19.3 {
            /*return new Resource(r.sourcePackId(), () -> new ByteArrayInputStream(nbtToStream(x).toByteArray()), r::metadata);
            *///?} else {
            return new class_3298(r.method_45304(), () -> new ByteArrayInputStream(nbtToStream(x).toByteArray()), r::method_14481);
            //?}
        }

        @Override
        public ByteArrayOutputStream export(class_2487 r) throws IOException {
            return nbtToStream(r);
        }
    };

    private static java.io.InputStream open(class_3298 resource) throws IOException {
        //? if <1.19 {
        /*return resource.getInputStream();
        *///?} else {
        return resource.method_14482();
        //?}
    }

    private static ByteArrayOutputStream bufferedImageToStream(BufferedImage image) throws IOException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        ImageIO.write(image, "png", stream);
        return stream;
    }

    private static ByteArrayOutputStream nbtToStream(class_2487 compound) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        class_2507.method_10634(compound, baos);
        return baos;
    }

}
