package net.rasanovum.rosetta.network;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_2540;

/** VarInt-sized collections, matching the former FriendlyByteBuf collection helpers. */
public final class PacketCollections {
    private PacketCollections() {}

    public static <T> void writeNullable(class_2540 buffer, T value, BiConsumer<class_2540, T> writer) {
        buffer.writeBoolean(value != null);
        if (value != null) writer.accept(buffer, value);
    }

    public static <T> T readNullable(class_2540 buffer, Function<class_2540, T> reader) {
        return buffer.readBoolean() ? reader.apply(buffer) : null;
    }

    public static <T> void write(class_2540 buffer, Collection<T> values, BiConsumer<class_2540, T> writer) {
        buffer.method_10804(values.size());
        for (T value : values) writer.accept(buffer, value);
    }

    public static <T> List<T> read(class_2540 buffer, Function<class_2540, T> reader) {
        int size = buffer.method_10816();
        if (size < 0) throw new IllegalArgumentException("Negative collection size: " + size);
        List<T> values = new ArrayList<>();
        for (int i = 0; i < size; i++) values.add(reader.apply(buffer));
        return values;
    }
}
