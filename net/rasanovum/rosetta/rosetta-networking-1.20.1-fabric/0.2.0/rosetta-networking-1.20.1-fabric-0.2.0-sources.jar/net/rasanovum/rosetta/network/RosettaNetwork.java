package net.rasanovum.rosetta.network;

import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.rasanovum.rosetta.util.RegistryCompat;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;

/** Packet registration and transport. */
public final class RosettaNetwork {
    private RosettaNetwork() {}

    public static Channel channel(String namespace) {
        return new Channel(namespace);
    }

    public static void sendToServer(RosettaPacket packet) {
        NetworkBackend.INSTANCE.sendToServer(packet);
    }

    public static void sendToPlayer(RosettaPacket packet, class_3222 player) {
        NetworkBackend.INSTANCE.sendToPlayer(packet, player);
    }

    @FunctionalInterface
    public interface ServerboundHandler<T> {
        void handle(T packet, class_3222 sender);
    }

    @FunctionalInterface
    public interface ClientboundHandler<T> {
        void handle(T packet, class_1657 player);
    }

    public static final class Channel {
        private final String namespace;
        private final Set<String> ids = new HashSet<>();

        private Channel(String namespace) {
            this.namespace = namespace;
        }

        public <T extends RosettaPacket> Channel serverbound(
                String id, Class<T> type, Function<class_2540, T> reader, ServerboundHandler<T> handler
        ) {
            NetworkBackend.INSTANCE.registerServerbound(PacketDefinition.serverbound(packetId(id), type, reader, handler));
            return this;
        }

        public <T extends RosettaPacket> Channel clientbound(
                String id, Class<T> type, Function<class_2540, T> reader, ClientboundHandler<T> handler
        ) {
            NetworkBackend.INSTANCE.registerClientbound(PacketDefinition.clientbound(packetId(id), type, reader, handler));
            return this;
        }

        private class_2960 packetId(String id) {
            if (!ids.add(id)) {
                throw new IllegalArgumentException("Duplicate packet id: " + namespace + ":" + id);
            }
            return RegistryCompat.getLocation(namespace, id);
        }
    }
}
