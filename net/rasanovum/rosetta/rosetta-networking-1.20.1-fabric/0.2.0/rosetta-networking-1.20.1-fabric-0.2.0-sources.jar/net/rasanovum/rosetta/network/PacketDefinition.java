package net.rasanovum.rosetta.network;

import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public record PacketDefinition<T extends RosettaPacket>(
        class_2960 id,
        Class<T> type,
        Function<class_2540, T> reader,
        RosettaNetwork.ServerboundHandler<T> serverboundHandler,
        RosettaNetwork.ClientboundHandler<T> clientboundHandler
) {
    public PacketDefinition {
        if ((serverboundHandler == null) == (clientboundHandler == null)) {
            throw new IllegalArgumentException("Exactly one packet handler direction is required");
        }
    }

    public static <T extends RosettaPacket> PacketDefinition<T> serverbound(
            class_2960 id, Class<T> type, Function<class_2540, T> reader,
            RosettaNetwork.ServerboundHandler<T> handler
    ) {
        return new PacketDefinition<>(id, type, reader, handler, null);
    }

    public static <T extends RosettaPacket> PacketDefinition<T> clientbound(
            class_2960 id, Class<T> type, Function<class_2540, T> reader,
            RosettaNetwork.ClientboundHandler<T> handler
    ) {
        return new PacketDefinition<>(id, type, reader, null, handler);
    }
}
