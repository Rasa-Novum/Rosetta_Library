package eu.midnightdust.lib.legacy;

import net.rasanovum.rosetta.client.gui.legacy.Tooltip;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.world.item.ItemStack;
import net.rasanovum.rosetta.client.gui.GuiCompat;

import java.util.Map;
import java.util.WeakHashMap;

public final class LegacyGui {
    private static final Map<AbstractWidget, Tooltip> TOOLTIPS = new WeakHashMap<>();
    private static Tooltip hoveredTooltip;

    private LegacyGui() {}

    public static void setTooltip(AbstractWidget widget, Tooltip tooltip) {
        TOOLTIPS.put(widget, tooltip);
    }

    public static void beginFrame() {
        hoveredTooltip = null;
    }

    public static void render(AbstractWidget widget, PoseStack pose, int mouseX, int mouseY, float delta) {
        widget.render(pose, mouseX, mouseY, delta);
        if (widget.visible && widget.isMouseOver(mouseX, mouseY)) {
            Tooltip tooltip = TOOLTIPS.get(widget);
            if (tooltip != null && !tooltip.text().getString().isEmpty()) hoveredTooltip = tooltip;
        }
    }

    public static void endFrame(PoseStack pose, int mouseX, int mouseY) {
        if (hoveredTooltip != null) {
            GuiCompat.renderTooltip(pose, Minecraft.getInstance().font, hoveredTooltip.text(), mouseX, mouseY);
        }
        hoveredTooltip = null;
    }

    public static void confirmLink(String url) {
        Minecraft minecraft = Minecraft.getInstance();
        var parent = minecraft.screen;
        minecraft.setScreen(new net.minecraft.client.gui.screens.ConfirmLinkScreen(confirmed -> {
            if (confirmed) net.minecraft.Util.getPlatform().openUri(url);
            minecraft.setScreen(parent);
        }, url, true));
    }

    public static void renderItem(PoseStack pose, ItemStack stack, int x, int y) {
        Minecraft.getInstance().getItemRenderer().renderAndDecorateItem(stack, x, y);
    }
}
