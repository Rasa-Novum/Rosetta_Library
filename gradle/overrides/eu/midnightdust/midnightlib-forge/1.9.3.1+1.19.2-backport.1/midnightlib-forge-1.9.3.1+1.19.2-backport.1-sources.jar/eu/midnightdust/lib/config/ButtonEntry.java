package eu.midnightdust.lib.config;

import com.google.common.collect.Lists;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
//? if <1.20 {
import com.mojang.blaze3d.vertex.PoseStack;
//?} else {
/*import com.mojang.blaze3d.vertex.PoseStack;
*///?}
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ContainerObjectSelectionList;
import net.rasanovum.rosetta.client.gui.legacy.MultiLineTextWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.core.Registry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
//? if >= 26.3-rc-2 {
/*import java.net.URI;
*///?}
//? if >= 1.21.9 {
/*import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.item.ItemStack;
*///?}
//? if >= 26.1-pre.1 {
/*import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponents;
*///?}

public class ButtonEntry extends ContainerObjectSelectionList.Entry<ButtonEntry> {
    private static final Font textRenderer = Minecraft.getInstance().font;
    public final Component text;
    public final List<AbstractWidget> buttons;
    public final EntryInfo info;
    public boolean centered = false;
    public MultiLineTextWidget title;

    public ButtonEntry(List<AbstractWidget> buttons, Component text, EntryInfo info) {
        this.buttons = buttons;
        this.text = text;
        this.info = info;
        if (info != null && info.comment != null)
            this.centered = info.comment.centered();
        int scaledWidth = Minecraft.getInstance().getWindow().getGuiScaledWidth();

        if (text != null && (!text.getString().contains("spacer") || !buttons.isEmpty())) {
            title = new MultiLineTextWidget(12, 0, text.copy(), textRenderer).setCentered(centered);
            if (info != null)
                title.setTooltip(info.getTooltip(false));
            int textWidth = scaledWidth - 24;
            if (!buttons.isEmpty()) {
                AbstractWidget control = buttons.get(buttons.size() > 2 ? buttons.size() - 1 : 0);
                //? if <1.20 {
                textWidth = control.x - 16;
                //?} else {
                /*textWidth = control.getX() - 16;
                *///?}
            }
            title.setMaxWidth(textWidth);
            if (centered) title.setX(scaledWidth / 2 - (title.getWidth() / 2));
        }
    }

    @Override
    //? if >= 1.21.9 {
    /*public void renderContent(PoseStack context, int mouseX, int mouseY, boolean hovered, float tickDelta) {
    int y = this.getY();
    *///?} else {
    public void render(PoseStack context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
    //?}
        buttons.forEach(b -> {
            //? if <1.20 {
b.y = y;
//?} else {
/*b.setY(y);
*///?}
            //? if <1.20 {
net.rasanovum.rosetta.client.gui.legacy.LegacyTooltips.render(b, context, mouseX, mouseY, tickDelta);
//?} else {
/*b.render(context, mouseX, mouseY, tickDelta);
*///?}
        });
        if (title != null) {
            title.setY(y + 5);
            //? if <1.20 {
net.rasanovum.rosetta.client.gui.legacy.LegacyTooltips.render(title, context, mouseX, mouseY, tickDelta);
//?} else {
/*title.render(context, mouseX, mouseY, tickDelta);
*///?}
        }
        if (info != null && info.entry != null && !this.buttons.isEmpty() && this.info.entry.idMode() != -1) {
            var id = ResourceLocation.tryParse(this.info.tempValue);
            var item = this.info.entry.idMode() == 0 ? Registry.ITEM./*? if >= 1.21.4 {*/ /*getValue *//*?} else {*/ get /*?}*/(id) : Registry.BLOCK./*? if >= 1.21.4 {*/ /*getValue *//*?} else {*/ get /*?}*/(id).asItem();
            var stack = /*? if >= 26.1-pre.1 {*/ /*new ItemStack(Holder.direct(item, DataComponentMap.builder().set(DataComponents.ITEM_MODEL, ResourceLocation.tryParse(this.info.tempValue)).build())) *//*?} else {*/ item.getDefaultInstance() /*?}*/;
//? if <1.20 {
net.rasanovum.rosetta.client.gui.GuiCompat.renderItem(context, stack, this.buttons.get(0).x + this.buttons.get(0).getWidth() - 18, y + 2);
//?} else {
            /*context./^? if >= 26.1-pre.1 {^/ /^fakeItem ^//^?} else {^/ renderItem /^?}^/(stack, this.buttons.get(0).getX() + this.buttons.get(0).getWidth() - 18, y + 2);
*///?}
        }
    }

    @Override
    //? if >= 1.21.9 {
    /*public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
    *///?} else {
    public boolean mouseClicked(double d, double e, int i) {
    //?}
        if (this.info != null && this.info.comment != null && !this.info.comment.url().isBlank())
            //? if >= 26.3-rc-2 {
            /*ConfirmLinkScreen.confirmLinkNow(Minecraft.getInstance().gui.screen(), URI.create(this.info.comment.url()), true);
            *///?} else if >= 26.2 {
            /*ConfirmLinkScreen.confirmLinkNow(Minecraft.getInstance().gui.screen(), this.info.comment.url(), true);
            *///?} else if >= 1.21 {
             /*ConfirmLinkScreen.confirmLinkNow(Minecraft.getInstance().screen, this.info.comment.url(), true);
            *///?} else {
            //? if <1.20 {
            net.rasanovum.rosetta.client.gui.GuiCompat.confirmLink(this.info.comment.url());
            //?} else {
            /*ConfirmLinkScreen.confirmLinkNow(this.info.comment.url(), Minecraft.getInstance().screen, true);
            *///?}
            //?}
        //? if >= 1.21.9 {
        /*return super.mouseClicked(click, doubled);
        *///?} else {
        return super.mouseClicked(d, e, i);
        //?}
    }

    public List<? extends GuiEventListener> children() {
        return Lists.newArrayList(buttons);
    }

    public List<? extends NarratableEntry> narratables() {
        return Lists.newArrayList(buttons);
    }
}