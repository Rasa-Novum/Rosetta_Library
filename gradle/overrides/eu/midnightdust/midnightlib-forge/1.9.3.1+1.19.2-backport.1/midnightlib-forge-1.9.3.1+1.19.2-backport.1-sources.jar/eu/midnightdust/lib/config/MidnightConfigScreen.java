package eu.midnightdust.lib.config;

import com.google.common.collect.Lists;
import net.minecraft.ChatFormatting;
import eu.midnightdust.lib.legacy.LegacyTabs.*;
import net.minecraft.locale.Language;
import net.minecraft.Util;
//? if <1.20 {
import com.mojang.blaze3d.vertex.PoseStack;
//?} else {
/*import com.mojang.blaze3d.vertex.PoseStack;
*///?}
import net.minecraft.client.gui.components.*;
import net.rasanovum.rosetta.client.gui.legacy.Button;
//? if <1.20 {
import net.rasanovum.rosetta.client.gui.legacy.Tooltip;
import eu.midnightdust.lib.legacy.TextAndImageButton;
//?}
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.ResourceLocation;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.*;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
//? if >= 1.21.9 {
/*import net.minecraft.client.input.KeyEvent;
*///?}

//? if >=1.21 {
/*import net.minecraft.client.gui.components.SpriteIconButton;
*///?}

public class MidnightConfigScreen extends Screen {
    public MidnightConfig instance;
    public final String translationPrefix, modid;
    public final Screen parent;
    public MidnightConfigListWidget list;
    public TabManager tabManager = new TabManager(a -> {}, a -> {});
    public Map<String, Tab> tabs = new LinkedHashMap<>();
    public Tab prevTab;
    public TabNavigationBar tabNavigation;
    public Button done;
    public double scrollProgress = 0d;

    public MidnightConfigScreen(Screen parent, String modid) {
        super(Component.translatable(modid + ".midnightconfig.title"));
        this.parent = parent;
        this.modid = modid;
        this.translationPrefix = modid + ".midnightconfig.";
        this.instance = MidnightConfig.configInstances.get(modid);
        instance.loadValuesFromJson();
        MidnightConfig.entries.values().forEach(info -> {
            if (Objects.equals(info.modid, modid)) {
                String tabId = info.entry != null ? info.entry.category() : info.comment.category();
                String name = translationPrefix + "category." + tabId;
                if (!Language.getInstance().has(name) && tabId.equals("default"))
                    name = translationPrefix + "title";
                if (!tabs.containsKey(name)) {
                    info.tab = new GridLayoutTab(Component.translatable(name));
                    tabs.put(name, info.tab);
                } else info.tab = tabs.get(name);
            }
        });
        //~ if >= 26.2-pre.3 'TabNavigationBar' -> 'MenuTabBar'
        tabNavigation = TabNavigationBar.builder(tabManager, this.width).addTabs(tabs.values().toArray(new Tab[0])).build();
        tabNavigation.selectTab(0, false);
        prevTab = tabManager.getCurrentTab();
    }

    // Real Time config update //
    @Override
    public void tick() {
        super.tick();
        if (prevTab != null && prevTab != tabManager.getCurrentTab()) {
            prevTab = tabManager.getCurrentTab();
            updateList();
            list.setScrollAmount(0);
        }
        scrollProgress = /*? if < 1.21.4 {*/ list.getScrollAmount() /*?} else {*/ /*list.scrollAmount() *//*?}*/;
        for (EntryInfo info : MidnightConfig.entries.values())
            if (Objects.equals(modid, info.modid)) info.updateFieldValue();
        updateButtons();
        if (instance.reloadScreen) {
            updateList();
            instance.reloadScreen = false;
        }
    }

    public void updateButtons() {
        if (this.list == null) return;

        for (ButtonEntry entry : this.list.children()) {
            if (entry.buttons != null && entry.buttons.size() > 1 && entry.info.field != null) {
                Optional.ofNullable(entry.buttons.get(0)).ifPresent(widget -> {
                    //? if <1.20 {
if (widget.isHoveredOrFocused())
//?} else {
/*if (widget.isFocused() || widget.isHovered())
*///?}
                        //? if <1.20 {
eu.midnightdust.lib.legacy.LegacyGui.setTooltip(widget, entry.info.getTooltip(true));
//?} else {
/*widget.setTooltip(entry.info.getTooltip(true));
*///?}
                });
                if (entry.buttons.get(1) instanceof Button button)
                    button.active = !Objects.equals(String.valueOf(entry.info.value), String.valueOf(entry.info.defaultValue)) && entry.info.conditionsMet;
            }
        }
    }

    @Override
    //? if >= 1.21.9 {
    /*public boolean keyPressed(KeyEvent input) {
        return this.tabNavigation.keyPressed(input) || super.keyPressed(input);
    }
    *///?} else {
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        return this.tabNavigation.keyPressed(key) || super.keyPressed(key, scanCode, modifiers);
    }
    //?}

    @Override
    public void onClose() {
        instance.loadValuesFromJson();
        MidnightConfig.entries.values().forEach(info -> {
            info.error = null;
            info.value = null;
            info.tempValue = null;
            info.actionButton = null;
            info.listIndex = 0;
            info.tab = null;
            info.inLimits = true;
        });
        //? if >= 26.2-pre.3 {
        /*Objects.requireNonNull(minecraft).setScreen(parent);
        *///?} else {
        Objects.requireNonNull(minecraft).setScreen(parent);
        //?}
    }

    @Override
    public void init() {
        super.init();
        //? if >= 26.2-pre.3 {
        /*tabNavigation.arrangeElements(this.width);
        *///?} else if >= 26.1-pre.3 {
        /*tabNavigation.updateWidth(this.width);
        tabNavigation.arrangeElements();
        *///?} else {
        tabNavigation.setWidth(this.width);
        tabNavigation.arrangeElements();
        //?}

        if (tabs.size() > 1)
            this.addRenderableWidget(tabNavigation);

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, button -> this.onClose()).bounds(this.width / 2 - 154, this.height - 26, 150, 20).build());
        done = this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, (button) -> {
            for (EntryInfo info : MidnightConfig.entries.values())
                if (info.modid.equals(modid))
                    info.updateFieldValue();
            MidnightConfig.write(modid);
            onClose();
        }).bounds(this.width / 2 + 4, this.height - 26, 150, 20).build());

        this.list = new MidnightConfigListWidget(this.minecraft, this.width, this.height - 57, 24, 25);
        this.addWidget(this.list);
        updateList();
        if (tabs.size() > 1)
            list.renderHeaderSeparator = false;
    }

    public void updateList() {
        this.list.clear();
        instance.onTabInit(prevTab.getTabTitle().getContents() instanceof TranslatableContents translatable ?
                translatable.getKey().substring(translatable.getKey().lastIndexOf('.') + 1) : prevTab.getTabTitle().toString(), list, this);
        for (EntryInfo info : MidnightConfig.entries.values()) {
            info.updateConditions();
            if (!info.conditionsMet) {
                boolean visibleButLocked = false;
                for (MidnightConfig.Condition condition : info.conditions)
                    visibleButLocked |= condition.visibleButLocked();
                if (!visibleButLocked) continue;
            }
            if (info.modid.equals(modid) && (info.tab == null || info.tab == tabManager.getCurrentTab())) {
                //? if >= 1.21 {
                 /*SpriteIconButton resetButton = SpriteIconButton.builder(Component.translatable("controls.reset"),
                *///?} else {
                TextAndImageButton resetButton = TextAndImageButton.builder(Component.translatable("controls.reset"), new ResourceLocation("midnightlib", "icon/reset.png"),
                //?}
                (button -> {
                    info.value = info.defaultValue;
                    info.listIndex = 0;
                    info.tempValue = info.toTemporaryValue();
                    updateList();
                })
                //? if >= 1.21 {
                 /*, true).sprite(ResourceLocation.fromNamespaceAndPath("midnightlib", "icon/reset"), 12, 12).size(20, 20).build();
                *///?} else {
                ).textureSize(12, 12).usedTextureSize(12, 12).offset(0, 4).build();
                resetButton.setWidth(20);
                //?}

                resetButton.setPosition(width - 205 + 150 + 25, 0);

                if (info.function != null) {
                    AbstractWidget widget;
                    MidnightConfig.Entry e = info.entry;
                    if (info.function instanceof Map.Entry) { // Enums & booleans
                        //noinspection unchecked
                        var values = (Map.Entry<Button.OnPress, Function<Object, Component>>) info.function;
                        if (info.dataType.isEnum()) {
                            values.setValue(value -> instance.getEnumTranslatableText(value, info));
                        }
                        widget = Button.builder(values.getValue().apply(info.value), values.getKey()).bounds(width - 185, 0, 150, 20).tooltip(info.getTooltip(true)).build();
                    } else if (e.isSlider())
                        widget = new MidnightSliderWidget(width - 185, 0, 150, 20, Component.nullToEmpty(info.tempValue), (Double.parseDouble(info.tempValue) - e.min()) / (e.max() - e.min()), info);
                    else
                        widget = new EditBox(font, width - 185, 0, 150, 20, Component.empty());

                    if (widget instanceof EditBox textField) {
                        textField.setMaxLength(e.width());
                        textField.setValue(info.tempValue);
                        //noinspection unchecked
                        Predicate<String> processor = ((BiFunction<EditBox, Button, Predicate<String>>) info.function).apply(textField, done);
                        //? if >= 26.1-pre.1 {
                        /*textField.setResponder(s -> {if (!processor.test(s)) textField.setValue(info.tempValue);});
                        *///?} else {
                        textField.setFilter(processor);
                         //?}
                    }
                    //? if <1.20 {
eu.midnightdust.lib.legacy.LegacyGui.setTooltip(widget, info.getTooltip(true));
//?} else {
/*widget.setTooltip(info.getTooltip(true));
*///?}

                    Button cycleButton = null;
                    if (info.field.getType() == List.class) {
                        cycleButton = Button.builder(Component.literal(String.valueOf(info.listIndex)).withStyle(ChatFormatting.GOLD), (button -> {
                            var values = (List<?>) info.value;
                            values.remove("");
                            info.listIndex = info.listIndex != values.size() ? info.listIndex + 1 : 0;
                            info.tempValue = info.listIndex != values.size() ? info.toTemporaryValue() : "";
                            updateList();
                        })).bounds(width - 185, 0, 20, 20).tooltip(Tooltip.create(Component.translatable("midnightconfig.action.list_index", info.listIndex))).build();
                    }
                    if (e.isColor()) {
                        Button colorButton = Button.builder(Component.literal("⬛"),
                                button -> new Thread(() -> {
                                    Color newColor = JColorChooser.showDialog(null, Component.translatable("midnightconfig.colorChooser.title").getString(), Color.decode(!Objects.equals(info.tempValue, "") ? info.tempValue : "#FFFFFF"));
                                    if (newColor != null) {
                                        info.setValue("#" + Integer.toHexString(newColor.getRGB()).substring(2));
                                        updateList();
                                    }
                                }).start()
                        ).bounds(width - 185, 0, 20, 20).tooltip(Tooltip.create(Component.translatable("midnightconfig.action.color_chooser"))).build();
                        try {
                            colorButton.setMessage(Component.literal("⬛").setStyle(Style.EMPTY.withColor(Color.decode(info.tempValue).getRGB())));
                        } catch (Exception ignored) {
                        }
                        info.actionButton = colorButton;
                    } else if (e.selectionMode() > -1) {
                        Button explorerButton =
                                //? if >= 1.21 {
                                 /*SpriteIconButton.builder(Component.empty(),
                                *///?} else {
                                TextAndImageButton.builder(Component.empty(), new ResourceLocation("midnightlib", "icon/explorer.png"),
                                //?}
                                button -> new Thread(() -> {
                                    JFileChooser fileChooser = new JFileChooser(info.tempValue);
                                    fileChooser.setFileSelectionMode(e.selectionMode());
                                    fileChooser.setDialogType(e.fileChooserType());
                                    fileChooser.setDialogTitle(Component.translatable(translationPrefix + info.fieldName + ".fileChooser").getString());
                                    if ((e.selectionMode() == JFileChooser.FILES_ONLY || e.selectionMode() == JFileChooser.FILES_AND_DIRECTORIES) && Arrays.stream(e.fileExtensions()).noneMatch("*"::equals))
                                        fileChooser.setFileFilter(new FileNameExtensionFilter(
                                                Component.translatable(translationPrefix + info.fieldName + ".fileFilter").getString(), e.fileExtensions()));
                                    if (fileChooser.showDialog(null, null) == JFileChooser.APPROVE_OPTION) {
                                        info.setValue(fileChooser.getSelectedFile().getAbsolutePath());
                                        updateList();
                                    }
                                }).start()
                                //? if >= 1.21 {
                                 /*, true).sprite(ResourceLocation.fromNamespaceAndPath("midnightlib", "icon/explorer"), 12, 12).size(20, 20)
                                *///?} else {
                                        ).textureSize(12, 12).usedTextureSize(12, 12).offset(0, 4)
                                //?}
                                .build();
                        //? if <1.20 {
eu.midnightdust.lib.legacy.LegacyGui.setTooltip(explorerButton, Tooltip.create(Component.translatable("midnightconfig.action.file_chooser")));
//?} else {
/*explorerButton.setTooltip(Tooltip.create(Component.translatable("midnightconfig.action.file_chooser")));
*///?}
                        explorerButton.setPosition(width - 185, 0);
                        info.actionButton = explorerButton;
                    }
                    List<AbstractWidget> widgets = Lists.newArrayList(widget, resetButton);

                    if (info.actionButton != null) {
                        if (Util.getPlatform() == Util.OS.OSX) info.actionButton.active = false;
                        widget.setWidth(widget.getWidth() - 22);
                        //? if <1.20 {
widget.x += 22;
//?} else {
/*widget.setX(widget.getX() + 22);
*///?}
                        widgets.add(info.actionButton);
                    }
                    if (cycleButton != null) {
                        //? if <1.20 {
if (info.actionButton != null) info.actionButton.x += 22;
//?} else {
/*if (info.actionButton != null) info.actionButton.setX(info.actionButton.getX() + 22);
*///?}
                        widget.setWidth(widget.getWidth() - 22);
                        //? if <1.20 {
widget.x += 22;
//?} else {
/*widget.setX(widget.getX() + 22);
*///?}
                        widgets.add(cycleButton);
                    }
                    if (!info.conditionsMet) widgets.forEach(w -> w.active = false);
                    this.list.addButton(widgets, Component.translatable(info.translationKey), info);
                } else {
                    Object[] formatter = {};
                    try {
                        Object value = info.field.get(null);
                        if (value instanceof Supplier<?> supplier) {
                             if (supplier.get() instanceof Object[] args) {
                                 formatter = args;
                             } else if (supplier.get() != null) {
                                 formatter = new Object[]{supplier.get()};
                             }
                        } else if (value instanceof Iterable<?> iterable) {
                            ArrayList<Object> list = new ArrayList<>();
                            iterable.forEach(list::add);
                            formatter = list.toArray();
                        } else if (value != null && value.getClass().isArray()) {
                            formatter = new Object[Array.getLength(value)];
                            for (int i = 0; i < Array.getLength(value); i++) {
                                formatter[i] = Array.get(value, i);
                            }
                        } else if (value != null) {
                            formatter = new Object[]{value};
                        }
                    } catch (IllegalAccessException ignored) {}
                    this.list.addButton(List.of(), Component.translatable(info.translationKey, formatter), info);
                }
            }
            list.setScrollAmount(scrollProgress);
            updateButtons();
        }
    }

    @Override
    public void render(PoseStack context, int mouseX, int mouseY, float delta) {
//? if <1.20
eu.midnightdust.lib.legacy.LegacyGui.beginFrame();
        //? if >= 1.21 {
         /*super.render(context, mouseX, mouseY, delta);
        *///?} else {
        super.renderBackground(context);
        //?}
        this.list.render(context, mouseX, mouseY, delta);
//? if <1.20 {
        if (tabs.size() < 2) net.rasanovum.rosetta.client.gui.GuiCompat.drawCenteredString(context, font, title, width / 2, 10, 0xFFFFFFFF);
//?} else {
        /*if (tabs.size() < 2) context.drawCenteredString(font, title, width / 2, 10, 0xFFFFFFFF);
*///?}
        //? if < 1.21
        super.render(context, mouseX, mouseY, delta);
//? if <1.20
eu.midnightdust.lib.legacy.LegacyGui.endFrame(context, mouseX, mouseY);
    }
}
