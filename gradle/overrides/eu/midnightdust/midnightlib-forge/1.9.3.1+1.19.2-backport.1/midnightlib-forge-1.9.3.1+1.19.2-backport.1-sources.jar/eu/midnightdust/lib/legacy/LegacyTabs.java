package eu.midnightdust.lib.legacy;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiComponent;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.rasanovum.rosetta.client.gui.GuiCompat;
import java.util.List;
import java.util.function.Consumer;

public final class LegacyTabs {
    private LegacyTabs() {}
    public interface Tab { Component getTabTitle(); }
    public record GridLayoutTab(Component title) implements Tab {
        public Component getTabTitle() { return title; }
    }
    public static final class TabManager {
        private Tab current;
        public TabManager(Consumer<AbstractWidget> add, Consumer<AbstractWidget> remove) {}
        public Tab getCurrentTab() { return current; }
    }
    public static final class TabNavigationBar extends AbstractWidget {
        private final TabManager manager;
        private final List<Tab> tabs;
        private int selected;
        private TabNavigationBar(TabManager manager, int width, List<Tab> tabs) {
            super(0, 0, width, 24, Component.empty());
            this.manager = manager;
            this.tabs = tabs;
        }
        public static Builder builder(TabManager manager, int width) { return new Builder(manager, width); }
        public void arrangeElements() {}
        public void selectTab(int index, boolean sound) {
            if (tabs.isEmpty()) return;
            selected = Math.floorMod(index, tabs.size());
            manager.current = tabs.get(selected);
            setMessage(manager.current.getTabTitle());
        }
        public boolean keyPressed(int key) {
            if (tabs.isEmpty()) return false;
            if (key == 258 && Screen.hasControlDown()) {
                selectTab(selected + (Screen.hasShiftDown() ? -1 : 1), true);
                return true;
            }
            if (isFocused() && (key == 262 || key == 263)) {
                selectTab(selected + (key == 262 ? 1 : -1), true);
                return true;
            }
            return false;
        }
        @Override
        public void onClick(double mouseX, double mouseY) {
            int index = (int) ((mouseX - tabLeft()) / tabWidth());
            if (mouseX >= tabLeft() && index < tabs.size() && mouseY >= tabTop(index)) {
                selectTab(index, true);
            }
        }
        private int tabWidth() {
            return Math.max(2, ((Math.min(400, width) - 28) / Math.max(1, tabs.size()) + 1) / 2 * 2);
        }

        private int tabLeft() {
            return x + (width - tabWidth() * tabs.size()) / 2;
        }

        private int tabTop(int index) {
            return y + (index == selected ? 1 : 5);
        }

        @Override
        public void renderButton(PoseStack pose, int mouseX, int mouseY, float delta) {
            var font = Minecraft.getInstance().font;
            GuiComponent.fill(pose, x, y, x + width, y + height, 0xFF000000);
            GuiComponent.fill(pose, x, y + height - 2, x + width, y + height - 1, 0xFF514A3E);
            for (int i = 0; i < tabs.size(); i++) {
                int left = tabLeft() + tabWidth() * i;
                int right = left + tabWidth() - 2;
                int top = tabTop(i);
                int bottom = y + height - 1;
                boolean hovered = mouseX >= left && mouseX < right && mouseY >= top && mouseY < bottom;
                int border = i == selected || hovered ? 0xFFE0D8C6 : 0xFF514A3E;
                GuiComponent.fill(pose, left, top, right, bottom, border);
                GuiCompat.blit(pose, GuiComponent.BACKGROUND_LOCATION, left + 1, top + 1,
                        0, 0, right - left - 2, bottom - top - 1, 32, 32);
                GuiComponent.fill(pose, left + 1, top + 1, right - 1, bottom, 0xBB000000);
                Component title = tabs.get(i).getTabTitle();
                int center = (left + right) / 2;
                GuiCompat.drawCenteredString(pose, font, title, center,
                        y + (i == selected ? 8 : 10), 0xFFFFFFFF);
                if (i == selected) {
                    int underlineWidth = Math.min(font.width(title), right - left - 4);
                    GuiComponent.fill(pose, center - underlineWidth / 2, bottom - 1,
                            center - underlineWidth / 2 + underlineWidth, bottom, 0xFFE0D8C6);
                }
            }
        }
        @Override
        public void updateNarration(NarrationElementOutput output) { defaultButtonNarrationText(output); }
        public static final class Builder {
            private final TabManager manager;
            private final int width;
            private List<Tab> tabs = List.of();
            private Builder(TabManager manager, int width) { this.manager = manager; this.width = width; }
            public Builder addTabs(Tab... tabs) { this.tabs = List.of(tabs); return this; }
            public TabNavigationBar build() { return new TabNavigationBar(manager, width, tabs); }
        }
    }
}
